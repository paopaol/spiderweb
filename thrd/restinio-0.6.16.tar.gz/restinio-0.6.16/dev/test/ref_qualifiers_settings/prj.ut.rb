require 'mxx_ru/binary_unittest'

Mxx_ru::setup_target(
	Mxx_ru::Binary_unittest_target.new(
		"test/ref_qualifiers_settings/prj.ut.rb",
		"test/ref_qualifiers_settings/prj.rb" )
)
