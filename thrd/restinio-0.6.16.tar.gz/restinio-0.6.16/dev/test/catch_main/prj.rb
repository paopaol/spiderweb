require 'mxx_ru/cpp'

MxxRu::Cpp::lib_target {
  target 'catch.main'
  cpp_source 'catch_main.cpp'
}

